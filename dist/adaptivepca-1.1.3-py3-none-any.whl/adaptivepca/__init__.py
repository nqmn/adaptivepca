from .adaptive_pca import AdaptivePCA  # assuming your class is in a file named adaptive_pca.py 
